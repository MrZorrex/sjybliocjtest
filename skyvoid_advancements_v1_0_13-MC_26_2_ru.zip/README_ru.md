Сообщество:	[![Static Badge](https://img.shields.io/badge/_-Discord-black?logo=discord&logoColor=%235865F2&labelColor=black&color=%235865F2)](https://discord.gg/mzWSZuGatd)
[![Github Badge](https://img.shields.io/badge/_-GitHub-black?logo=github&logoColor=white&labelColor=%23181717&color=white&)](https://github.com/BPR02/SkyBlock_Collection)  
Скачать: [![Smithed Badge](https://img.shields.io/badge/_-Smithed-black?logo=hackthebox&logoColor=%231b48c4&labelColor=black&color=%231b48c4)](https://smithed.net/packs/skyblock-advancements)
[![Modrinth Badge](https://img.shields.io/badge/_-Modrinth-black?logo=modrinth&logoColor=%2300AF5C&labelColor=black&color=%2300AF5C)](https://modrinth.com/datapack/skyblock-advancements)  
Поддержка: [![PayPal Badge](https://img.shields.io/badge/_%20-Paypal-black?logo=paypal&logoColor=%230079C1&labelColor=black&color=%230079C1)](https://www.paypal.com/paypalme/epyonprojects)
[![BisectHosting Badge](https://img.shields.io/badge/%D0%90%D1%80%D0%B5%D0%BD%D0%B4%D0%B0%20%D1%81%D0%B5%D1%80%D0%B2%D0%B5%D1%80%D0%B0-black?logo=bisecthosting&logoColor=%2306ddff&labelColor=%23030525&color=%2337e3f3)](https://www.bisecthosting.com/skyvoid)

# SkyBlock Advancements (русская версия)
Этот датапак изменяет достижения сюжетной вкладки и вкладки Нижнего мира, чтобы лучше направлять прогресс в мире SkyBlock. Он перераспределяет ванильные достижения и добавляет новые. Идеально подходит для карт SkyBlock, например [Standard SkyBlock](https://smithed.net/packs/standard-skyblock)!

## Перестроено под прогресс SkyBlock
Достижения сюжетной вкладки переписаны и переставлены под прогресс SkyBlock вместо ванильного. Например, достижение о железном слитке перенесено после нового достижения об убийстве зомби, потому что первое железо в SkyBlock добывается не из железной руды, а с зомби.

![Достижение «Железный слиток»](https://raw.githubusercontent.com/BPR02/SkyBlock_Collection/main/images/iron_ingot_advancement.png)

## Направляющий опыт
В датапаке есть несколько дополнительных достижений, которые помогают проходить игру без знания случайных особенностей механик. Например, они объясняют, как построить генератор булыжника, как получить вторую воду с помощью костной муки, как получить траву без шёлкового касания и как получить второй источник лавы. Большинство этих достижений подсказывают решение, а не говорят его напрямую.

![Достижение «Сердце добычи»](https://raw.githubusercontent.com/BPR02/SkyBlock_Collection/main/images/cobblestone_gen_advancement.png)

![Достижение «Котёл»](https://raw.githubusercontent.com/BPR02/SkyBlock_Collection/main/images/cauldron_advancement.png)

## Русификация
Все названия и описания достижений, а также описание пака переведены на русский язык. Перевод находится в `assets/skyvoid/lang/ru_ru.json` и применяется автоматически, когда в игре выбран русский язык. Английские тексты сохранены как запасные (`fallback`) прямо в файлах достижений.
